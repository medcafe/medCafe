============
thumb_margin
============


    | type: **Number**
    | default: **0**

Same as **image_margin** but for thumbnails.