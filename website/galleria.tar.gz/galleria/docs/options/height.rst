======
height
======

    | type: **Number** or **String**
    | default: **'auto'**

Galleria need a height to work properly. You can set the height using this option to make sure it has the correct height.
If no height is set, Galleria will try to find the height of the parent container.