==================
overlay_background
==================

    | type: **String**
    | default: **#0b0b0b**

This defines the overlay background color when calling ``showLightbox()``