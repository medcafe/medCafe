===============
max_scale_ratio
===============

    | type: **Number**
    | default: **undefined**

Sets the maximum scale ratio for images.
F.ex, if you don't want Galleria to upscale any images, set this to 1.

undefined will allow any scaling of the images.