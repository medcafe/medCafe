===========
popup_links
===========

    | type: **Boolean**
    | default: **false**

Setting this to **true** will open any image links in a new window.
You can add image links using the longdesc attribute (default) or customize it using data_config