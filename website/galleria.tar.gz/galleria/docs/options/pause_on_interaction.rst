====================
pause_on_interaction
====================

    | type: **Boolean**
    | default: **true**

During playback, Galleria will stop the playback if the user presses thumbnails or any other navigational links.
If you dont want this behaviour, set this option to ``false``.