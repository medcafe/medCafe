=========
idle_time
=========

    | type: **Number**
    | default: **3000**

If you are adding elements into idle mode using the ``addIdleState()`` method,
you can control the delay before Galleria falls into Idle mode using this option.

idle_time is set using milliseconds, so 3000 equals 3 full seconds.