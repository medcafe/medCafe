=========
clicknext
=========

    | type: **Boolean**
    | default: **false**

This options adds a click event over the stage that navigates to the next image in the gallery.
Useful for mobile browsers and other simpler applications.

Note that setting this to ``true`` will disable any other links that you might have in the data object.