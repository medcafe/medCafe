============
show_counter
============

    | type: **Boolean**
    | default: **true**

Set this to false if you do not wish to display the counter.