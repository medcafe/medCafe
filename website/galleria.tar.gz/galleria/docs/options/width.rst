=====
width
=====

    | type: **Number** or **String**
    | default: **'auto'**

By default, Galleria fetches the width from the containing element.
Bu you can use this option to set a gallery width manually.