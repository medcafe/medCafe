==========
thumb_crop
==========

    | type: **Boolean** or **String**
    | default: **true**

Same as **image_crop** but for thumbnails.